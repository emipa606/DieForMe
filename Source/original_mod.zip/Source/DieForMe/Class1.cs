﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using RimWorld;
using Verse;

namespace DieForMe
{

    public class Hediff_HighExplosiveDeadManSwitch : HediffWithComps
    {
        public Hediff_HighExplosiveDeadManSwitch()
        {
        }

        public override void Notify_PawnDied()
        {
            base.Notify_PawnDied();
            GenExplosion.DoExplosion(this.pawn.Corpse.Position, this.pawn.Corpse.Map, 3.5f, DamageDefOf.Bomb, this.pawn.Corpse.InnerPawn, -1, -1f, null, null, null, null, null, 0f, 1, true, null, 0f, 1, 0f, false);
            this.pawn.health.RemoveHediff(this);
        }
    }

    public class Hediff_IncendiaryDeadManSwitch : HediffWithComps
    {
        public Hediff_IncendiaryDeadManSwitch()
        {
        }

        public override void Notify_PawnDied()
        {
            base.Notify_PawnDied();
            GenExplosion.DoExplosion(this.pawn.Corpse.Position, this.pawn.Corpse.Map, 3.5f, DamageDefOf.Flame, this.pawn.Corpse.InnerPawn, -1, -1f, null, null, null, null, null, 0f, 1, false, null, 0f, 1, 0f, false);
            this.pawn.health.RemoveHediff(this);
        }
    }



    public class Hediff_EMPDeadManSwitch : HediffWithComps
    {

        public Hediff_EMPDeadManSwitch()
        {
        }

        public override void Notify_PawnDied()
        {
            base.Notify_PawnDied();
            GenExplosion.DoExplosion(this.pawn.Corpse.Position, this.pawn.Corpse.Map, 5.5f, DamageDefOf.EMP, this.pawn.Corpse.InnerPawn, -1, 1f, null, null, null, null, null, 0f, 1, true, null, 0f, 1, 0f, false);
            this.pawn.health.RemoveHediff(this);
        }
    }


    public class Hediff_FirefoamDeadManSwitch : HediffWithComps
    {

        public Hediff_FirefoamDeadManSwitch()
        {
        }

        public override void Notify_PawnDied()
        {
            base.Notify_PawnDied();
            GenExplosion.DoExplosion(this.pawn.Corpse.Position, this.pawn.Corpse.Map, 5.5f, DamageDefOf.Extinguish, this.pawn.Corpse.InnerPawn, -1, 1f, null, null, null, null, ThingDefOf.Filth_FireFoam, 1.0f, 100, true, null, 0f, 1, 0f, false);
            this.pawn.health.RemoveHediff(this);
        }
    }
}